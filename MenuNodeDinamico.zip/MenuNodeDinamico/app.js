require('colors');

const { mostrarMenu } = require('./helpers/mensajes');

// const{inquirerMenu} = require('');
// const Tarea = require('./models/tareas');

// console.log(`${'M'.red}${'e'.blue}${'n'.yellow}${'u'.green}`);

const main = async()=>{
    // console.log('Main');
    mostrarMenu();
}

main();