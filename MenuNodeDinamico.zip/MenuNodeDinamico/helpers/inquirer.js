require('colors');

const inquirer = require('inquirer');
const prompt = inquirer.createPromptModule();

const preguntas =[
    {
        type: 'list',
        name: 'option',
        menssages: 'Que deseas hacer?',
        choises: [
            {
                value: '1',
                name: `${'1. '.red}opcion 1`
            },
            {
                value: '2',
                name: `${'2. '.red}opcion 2`
            },
            {
                value: '3',
                name: `${'3. '.red}opcion 3`
            },
            {
                value: '4',
                name: `${'4. '.red}opcion 4`
            },
            {
                value: '5',
                name: `${'5. '.red}opcion 5`
            },
            {
                value: '6',
                name: `${'6. '.red}opcion 6`
            },
            {
                value: '0',
                name: `${'0. '.red}salir`
            }
        ]

    }
    
]

const inquirerMenu = async () =>{
    console.log("xXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXx".blue);
    console.log("                      Seleccione una opcion                         ".yellow);
    console.log("xXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXx".blue);
   

    let otp ='';

    const opt = await prompt(preguntas).then(data =>{

        otp= data['option']
    });
    return otp;
}

const pausa = async()=> {
    const question=[
        {
            type:'input',
            name:'enter',
            message:`\nPresione ${'ENTER'.red} para continuar \n`
        }
    ]

    let pau = '';
    console.log('\n');
    await inquirer.prompt(question).then(data =>{
        pau= data['message']
    });
}

const leerInput = async()=>{
    const question =[
        {
            type:'input',
            name:'desc',
            message,
            validate(value){
                if(value.length ===0){
                    return 'Por favor ingrese un valor';
                }
                return true;
            }
        }
        
    ]
}

module.exports={
    inquirerMenu
}