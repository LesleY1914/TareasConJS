const { stdin, stdout } = require('process');

require('colors');


const mostrarMenu = () =>{
    return new Promise(resolve =>{
        console.clear();
        console.log("=================================================================".blue);
        console.log("                      Seleccione una opcion                         ".yellow);
        console.log("=================================================================".blue);
        console.log(`${'1. '.red}opcion 1`);
        console.log(`${'2. '.red}opcion 2`);
        console.log(`${'3. '.red}opcion 3`);
        console.log(`${'4. '.red}opcion 4`);
        console.log(`${'5. '.red}opcion 5`);
        console.log(`${'6. '.red}opcion 6`);
        console.log(`${'0. '.red}salir \n`);
        
        const readline = require('readline').createInterface({
            input: stdin,
            output: stdout
        })

        readline.question('Seleccione una opcion: ', (otp) => {
            readline.close();
            otp=otp
            // console.log(opt);
            resolve(otp);
       
        })
    })
}




module.exports = {
    mostrarMenu
}