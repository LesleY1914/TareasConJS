const{v4: uuidv4 }=require('uuid');

class Tarea {

    id= '';
    desc= '';
    completadoEn= null;
    
    
}